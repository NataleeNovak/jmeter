/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.73327204004495, "KoPercent": 1.2667279599550516};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9855565469551639, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "SC_openClients"], "isController": false}, {"data": [0.961372064276885, 500, 1500, "SC_AddComment"], "isController": true}, {"data": [0.9987639060568603, 500, 1500, "SC_OpenGuestBook"], "isController": true}, {"data": [1.0, 500, 1500, "CGH_openSite"], "isController": false}, {"data": [1.0, 500, 1500, "SC_OpenSite"], "isController": true}, {"data": [0.9666666666666667, 500, 1500, "CGH_deleteComments"], "isController": false}, {"data": [1.0, 500, 1500, "SC_openSite"], "isController": false}, {"data": [0.9705882352941176, 500, 1500, "CGH_clearGuestbookHistory"], "isController": true}, {"data": [1.0, 500, 1500, "CGH_OpenSite"], "isController": true}, {"data": [1.0, 500, 1500, "SC_OpenClients"], "isController": true}, {"data": [0.9993819530284301, 500, 1500, "SC_openGuestbook"], "isController": false}, {"data": [0.9615265760197775, 500, 1500, "SC_addComment"], "isController": false}, {"data": [1.0, 500, 1500, "CGH_openNewGuestbook"], "isController": false}, {"data": [1.0, 500, 1500, "CGH_OpenGuestbook"], "isController": true}, {"data": [0.9585908529048207, 500, 1500, "SC_sendComment"], "isController": true}, {"data": [1.0, 500, 1500, "CGH_openGuestbook"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 9789, 124, 1.2667279599550516, 5.8256205945448825, 1, 650, 4.0, 5.0, 115.0, 32.57787539936102, 222.6327654398795, 12.722567069771697], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["SC_openClients", 1618, 0, 0.0, 2.96168108776267, 2, 113, 3.0, 4.0, 7.0, 5.392955826425483, 32.31033593273471, 2.111889928121698], "isController": false}, {"data": ["SC_AddComment", 1618, 62, 3.831891223733004, 14.429542645241034, 3, 764, 8.0, 16.049999999999955, 264.6199999999999, 5.389111862374473, 24.859608671124285, 4.809497534223191], "isController": true}, {"data": ["SC_OpenGuestBook", 1618, 0, 0.0, 13.380716934487012, 3, 652, 7.0, 22.049999999999955, 241.24999999999864, 5.391841590493297, 44.61435265930592, 3.8648552025606246], "isController": true}, {"data": ["CGH_openSite", 17, 0, 0.0, 13.529411764705882, 3, 135, 46.19999999999992, 135.0, 135.0, 0.060405355467750645, 1.336291520909136, 0.022534029090508542], "isController": false}, {"data": ["SC_OpenSite", 1619, 0, 0.0, 3.6794317479925853, 0, 119, 4.0, 5.0, 8.0, 5.384784242770952, 119.04930632757882, 1.8708975943085593], "isController": true}, {"data": ["CGH_deleteComments", 15, 0, 0.0, 40.733333333333334, 1, 557, 242.6000000000002, 557.0, 557.0, 0.0533766039669492, 5.525312520016227E-4, 0.0], "isController": false}, {"data": ["SC_openSite", 1618, 0, 0.0, 3.6810877626699625, 2, 119, 4.0, 5.0, 8.0, 5.391392432057792, 119.26907159776647, 1.874351275207592], "isController": false}, {"data": ["CGH_clearGuestbookHistory", 17, 0, 0.0, 75.4705882352941, 10, 710, 267.5999999999996, 710.0, 710.0, 0.06033054038419908, 1.9787640933916766, 0.08162713796352486], "isController": true}, {"data": ["CGH_OpenSite", 18, 0, 0.0, 12.777777777777779, 0, 135, 35.10000000000016, 135.0, 135.0, 0.06387916900298812, 1.3346317199554976, 0.022506039686708165], "isController": true}, {"data": ["SC_OpenClients", 1618, 0, 0.0, 2.9635352286773795, 2, 113, 3.0, 4.0, 7.0, 5.392937851224244, 32.31022823951243, 2.1118828890048063], "isController": true}, {"data": ["SC_openGuestbook", 3236, 0, 0.0, 6.690049443757743, 1, 650, 3.0, 4.0, 116.63000000000011, 10.783719116774748, 44.614501333177266, 3.86486808189095], "isController": false}, {"data": ["SC_addComment", 3236, 124, 3.831891223733004, 7.21477132262052, 1, 532, 4.0, 8.0, 125.63000000000011, 10.778295523809842, 24.859774273231125, 4.809529572656903], "isController": false}, {"data": ["CGH_openNewGuestbook", 15, 0, 0.0, 9.2, 1, 85, 47.200000000000024, 85.0, 85.0, 0.05346659585313083, 0.014202064523487877, 0.01665609773159056], "isController": false}, {"data": ["CGH_OpenGuestbook", 17, 0, 0.0, 17.88235294117647, 4, 154, 53.999999999999915, 154.0, 154.0, 0.06040192149171428, 0.6301813523279611, 0.04258807355177511], "isController": true}, {"data": ["SC_sendComment", 1618, 62, 3.831891223733004, 34.45241038318912, 11, 1050, 24.0, 66.04999999999995, 465.0, 5.3832845355336705, 220.71837647849014, 12.6426536350895], "isController": true}, {"data": ["CGH_openGuestbook", 34, 0, 0.0, 8.941176470588236, 2, 151, 14.5, 57.25, 151.0, 0.12080427220755595, 0.6301835914044207, 0.04258822487004658], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E\'&lt;br&gt;$)\\\/", 19, 15.32258064516129, 0.19409541321891918], "isController": false}, {"data": ["Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!\'&lt;br&gt;$)\\\/", 12, 9.67741935483871, 0.1225865767698437], "isController": false}, {"data": ["500", 62, 50.0, 0.6333639799775258], "isController": false}, {"data": ["Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u041E\\u0442\\u043B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u0440\\u0435\\u0431\\u044F\\u0442\\u0430.\'&lt;br&gt;$)\\\/", 13, 10.483870967741936, 0.13280212483399734], "isController": false}, {"data": ["Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0411\\u043B\\u0430\\u0433\\u043E\\u0434\\u0430\\u0440\\u044E \\u0437\\u0430 \\u043E\\u0442\\u043B\\u0438\\u0447\\u043D\\u0443\\u044E \\u0440\\u0430\\u0431\\u043E\\u0442\\u0443!\'&lt;br&gt;$)\\\/", 16, 12.903225806451612, 0.16344876902645827], "isController": false}, {"data": ["Response was null", 2, 1.6129032258064515, 0.020431096128307284], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 9789, 124, "500", 62, "Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E\'&lt;br&gt;$)\\\/", 19, "Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0411\\u043B\\u0430\\u0433\\u043E\\u0434\\u0430\\u0440\\u044E \\u0437\\u0430 \\u043E\\u0442\\u043B\\u0438\\u0447\\u043D\\u0443\\u044E \\u0440\\u0430\\u0431\\u043E\\u0442\\u0443!\'&lt;br&gt;$)\\\/", 16, "Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u041E\\u0442\\u043B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u0440\\u0435\\u0431\\u044F\\u0442\\u0430.\'&lt;br&gt;$)\\\/", 13, "Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!\'&lt;br&gt;$)\\\/", 12], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["SC_addComment", 3236, 124, "500", 62, "Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E\'&lt;br&gt;$)\\\/", 19, "Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0411\\u043B\\u0430\\u0433\\u043E\\u0434\\u0430\\u0440\\u044E \\u0437\\u0430 \\u043E\\u0442\\u043B\\u0438\\u0447\\u043D\\u0443\\u044E \\u0440\\u0430\\u0431\\u043E\\u0442\\u0443!\'&lt;br&gt;$)\\\/", 16, "Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u041E\\u0442\\u043B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u0440\\u0435\\u0431\\u044F\\u0442\\u0430.\'&lt;br&gt;$)\\\/", 13, "Test failed: text expected to contain \\\/(&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!\'&lt;br&gt;$)\\\/", 12], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
